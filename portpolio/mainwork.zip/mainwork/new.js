const http = require('http');

const hostname = '127.0.0.1';
const port = 3000;

const server = http.createServer((req, res) => {
  res.statusCode = 200;
  res.setHeader('Content-Type', 'text/html');
  res.end(`<!DOCTYPE html>
  <html lang="en">
  <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Document</title>
      <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Mouse Memoirs">
  <link rel="icon" href="dank.png">
  </head>
  <style>
      .logo{
          height: 100px;
          width: 100px;
          display: block;
          margin-left: auto;
          margin-right: auto
      }
      .container1{
          display: block;
          height: auto;
          width: auto;
          margin-left: auto;
      margin-right: auto;
      
        }  
  .nav{
      display:flex;
      justify-content: center;
      height: auto;
      width: auto;
      border: solid;
      background-color: rgb(252, 252, 252);
      border-color: rgb(253, 252, 252);
      margin-top: 20px;
      box-shadow: 5px -5px rgb(71, 71, 72);
      box-shadow: -5px 5px rgb(71, 71, 72);
  }
  .nav a{
      text-decoration: none;
      padding:  20px;
      font-size: 20px;
      color: rgb(21, 13, 13);
  }
  .nav a:hover{
      text-decoration: underline;
      box-shadow: rgba(50, 50, 93, 0.25) 0px 30px 60px -12px inset, rgba(0, 0, 0, 0.3) 0px 18px 36px -18px inset;
      
  }
  
  .container2{
  margin-top: 30px;
      display: grid;
      grid-auto-flow: column;
      grid-template-columns: 1fr;
      box-shadow: -5px 5px rgb(165, 165, 167);
     padding-left: 20px;
  }
  .think{
      height: 400px;
      width: 500px;
  }
  .heading1{
      font-size: 40px;
      font-family: cursive;
  }
  .container3{
      display: flex;
  justify-content: center;
  justify-content: space-evenly;
  margin-top: 40px;
  
  }
  .box{
      height: 330px;
      width: 320px;
      border: solid;
      padding: 20px 20px 20px 20px;
      border-top-right-radius: 20px;
      border-bottom-left-radius: 20px;
      border-color: aliceblue;
      box-shadow: rgba(0, 0, 0, 0.25) 0px 54px 55px, rgba(0, 0, 0, 0.12) 0px -12px 30px, rgba(0, 0, 0, 0.12) 0px 4px 6px, rgba(0, 0, 0, 0.17) 0px 12px 13px, rgba(0, 0, 0, 0.09) 0px -3px 5px;
  }
  .box:hover{
      box-shadow: rgba(50, 50, 93, 0.25) 0px 30px 60px -12px inset, rgba(0, 0, 0, 0.3) 0px 18px 36px -18px inset;
  }
  .heading2{
      display: flex;
      justify-content: center;
      width: 320;
      height: auto;
      background-color: black;
   font-size: large;
      opacity: 0.7;
      color: aliceblue;
      margin-top: 20px;
  }
  
  
  .container3 img{
      margin-left: auto;
      margin-right: auto;
  }
  .logo2{
      display: flex;
     justify-content: center;
  }
  .testimoney{
   margin-top: 20px ;
   display:flex ;
   justify-content: space-around;
  }
  .testimoney box1 b{
      z-index: 1;
  }
  .box1{
      height: 130px;
      width: 380px;
      border: solid;
      padding: 20px 20px 20px 20px;
      border-top-right-radius: 20px;
      border-bottom-left-radius: 20px;
      border-color: aliceblue;
      background-color: rgb(227, 228, 229);
      
      box-shadow: rgba(0, 0, 0, 0.25) 0px 54px 55px, rgba(0, 0, 0, 0.12) 0px -12px 30px, rgba(0, 0, 0, 0.12) 0px 4px 6px, rgba(0, 0, 0, 0.17) 0px 12px 13px, rgba(0, 0, 0, 0.09) 0px -3px 5px;
  }
  .testhead{
      margin-top: 20px;
      display: flex;
    justify-content: center;
    margin-top: 30px;
  
  }
  .end{
      margin-top: 40px;
          height: auto;
      width: 100%;
      display: flex;
      justify-content: space-around;
      color:white;
      border:solid;
      background-color: black;
      opacity: 0.7;
  }
  .boxl a {
      text-decoration: none;
      
  }
  
  
  .button {
    align-items: center;
    background-color: #fee6e3;
    border: 2px solid #111;
    border-radius: 8px;
    box-sizing: border-box;
    color: #111;
    cursor: pointer;
    display: flex;
    font-family: Inter,sans-serif;
    font-size: 16px;
    height: 48px;
    justify-content: center;
    line-height: 24px;
    max-width: 100%;
    padding: 0 25px;
    position: relative;
    text-align: center;
    text-decoration: none;
    user-select: none;
    -webkit-user-select: none;
    touch-action: manipulation;
  }
  
  .button:after {
    background-color: #111;
    border-radius: 8px;
    content: "";
    display: block;
    height: 48px;
    left: 0;
    width: 100%;
    position: absolute;
    top: -2px;
    transform: translate(8px, 8px);
    transition: transform .2s ease-out;
    z-index: -1;
  }
  
  .button:hover:after {
    transform: translate(0, 0);
  }
  
  .button:active {
    background-color: #ffdeda;
    outline: 0;
  }
  
  .button:hover {
    outline: 0;
  }
  
  @media (min-width: 768px ) {
    .button {
      padding: 0 40px;
    }
  }
  @media only screen and (min-width: 500px ) and (max-width:1130px)   {
      .para1{
      /*background-image: url(back.png);*/
      background-repeat: no-repeat;
      background-position: center;
      
  
  }
  .box{
      height: auto;
  }
  .think{
      display: none;
  }
  
  }
  @media only screen and (max-width: 500px) {
   
   .container3{
      display: inline;
      justify-content: center;
      margin-top: 40px;
   }
   .box{
     margin-left: auto;
     margin-right: auto;
     margin-top: 40px;
   }
   .testimoney{
      display: inline;
   }
   .box1{
     margin-left: auto;
    margin-right: auto;
    margin-top: 5px;
   }
   .para1{
      background-image: url(back.png);
      background-repeat: no-repeat;
      background-position: center;
  
  }
  .think{
      display: none;
  }
  }
  </style>
  <body>
      
      <div class="container1">
      <div class="nav">
          <a href="">HOME</a><a href="resouces.html">RESOURCES</a><a href="mainquiz.html">QUIZ</a><a href="">ABOUT US</a>
      </div></div>
      <div class="container2">
          <div class="text1">
  <div class="heading1">
      Why Learn to Code?
  </div>
  <div class="para1">
      Coding tests a variety of abilities. It hones problem-solving and analysis skills, such as finding errors and thinking logically. Further, coding often helps people develop teamwork and interpersonal skills since software and application projects are often cross-disciplinary and collaborative.
      You are a non-programmer who wonders how things work in this technical era. You are interested in technology and thinking about choosing this path.You are a beginner, just have entered this field and you have doubts whether you took the correct step in choosing this field or not. It is scary or frustrating for you or maybe fun for you.You are an experienced person and you want to know that after choosing this field how far you have come and what changes you have experienced throughout your journey in programming
  </div>
          </div>
          <div class="img">
           <img src="thinking.png" class="think">
          </div>
      </div>
      <div class="container3">
          <div class="box" ><img src="python.png" alt=""height="100px" width="100px" class="logo2" >
        
              
                  <div class="heading2">python</div>
             
              <p>
                  Python is one of the most demanded programming languages in the job market. Surprisingly, it is equally easy to learn and master Python. Let's commit our 100 days of code to python!
              </p>
              <ul>
                  <li>notes</li>
                  <li>quizes</li>
                  <li>questions</li>
              </ul>
          </div>
          <div class="box" ><img src="java.png" alt=""height="100px" width="100px" class="logo2">
              <div class="heading2">java</div><p>
              This latest  course comes with premium curriculum that covers everything from basics to advance. On top of that, you will get my handwritten notes of J for completely free. What are you waiting for? Just Enroll Buddy
          </p>
          <ul>
              <li>notes</li>
              <li>quizes</li>
              <li>questions</li>
          </ul></div>
          <div class="box"><img src="c.png" alt="" height="100px" width="100px" class="logo2">
              <div class="heading2">C programming</div><P>
              Since the late 19th century, C has been a popular programming language for general-purpose use.
  C language was developed by Dennis M. Ritchie at bell laboratory in early 1970s⁣
  Its applications are very diverse. It ranges from developing operating systems to databases.
          </P>
          <ul>
              <li>notes</li>
              <li>quizes</li>
              <li>questions</li>
          </ul></heading></div>
      </div>
      <div class="testhead"><h1>Testimonials</h1></div>
      <div class="testimoney">
          <div class="box1">
    <p>
      <b>Doug Roussin Cohort </b>Three Graduate
  Careers in Code has opened up possibilities for my future. It has given me a solid foundation of full-stack coding skills, as well as an introduction to people in the Syracuse tech community. I’m excited to continue growing those skills and connections to the community.
    </p>
          </div>
  
          <div class="box1"><p><b>Karin Thorne,</b>"I started the program knowing nothing about code, not even most of the terminology. After completing the 24 weeks, I can talk comfortably with seasoned developers because now I am a Full Stack Developer!"</p></div>
      </div>
      <div class="end">
          <div class="boxl"><button  class="button"><a href="resouces.html">about us</a></button></div>
          <div class="boxl"><button  class="button"><a href="resouces.html">quizes</a></button></div>
          <div class="boxl"><button  class="button"><a href="resouces.html">resouces</a></button></div>
        
      </div>
  </body>
  </html>`);
});

server.listen(port, hostname, () => {
  console.log(`Server running at http://${hostname}:${port}/`);
});